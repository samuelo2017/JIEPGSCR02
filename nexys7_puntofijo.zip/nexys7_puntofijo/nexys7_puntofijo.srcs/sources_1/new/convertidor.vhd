library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity convertidor is
Port (
    X : in UNSIGNED (3 downto 0);    --entrada bcd
    Ka : out std_logic_vector (6 downto 0)          --salida 7 segmentos [a b c d e f g ]
);
end convertidor;

architecture Behavioral of convertidor is
begin
procX:process(X) is
begin
    case X is
        when "0000" => -- 0
            Ka <= "0000001";
        when "0001" => -- 1
            Ka <= "1001111";
        when "0010" => -- 2
            Ka <= "0010010";
        when "0011" => -- 3
            Ka <= "0000110"; 
        when "0100" => -- 4
            Ka <= "1001100"; 
        when "0101" => -- 5
            Ka <= "0100100";
        when "0110" => -- 6
            Ka <= "0100000";  
        when "0111" => -- 7
            Ka <= "0001111";
        when "1000" => -- 8
            Ka <= "0000000";
        when "1001" => -- 9
            Ka <= "0000100";
        when others =>
            Ka <= "1111111";
    end case;
end process procX;

end Behavioral;
