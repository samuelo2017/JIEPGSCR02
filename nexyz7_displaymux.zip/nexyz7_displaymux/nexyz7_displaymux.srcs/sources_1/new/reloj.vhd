library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
--Declaración de entidad
entity reloj is
    Port ( fastClock : in STD_LOGIC;              --entrada reloj
            slowClock : inout STD_LOGIC;          --salida reloj
            prescaler : in INTEGER RANGE 0 TO 50000000);
end reloj;

--Definición de la arquitectura
architecture Behavioral of reloj is
begin
slowClockProcess: process(fastClock)
        variable countFastCycles: INTEGER RANGE 0 TO 50000000;
begin
        if  rising_edge(fastClock) then 
            countFastCycles := countFastCycles + 1;           
            if countFastCycles = prescaler then
                slowClock <= NOT slowClock;
                countFastCycles := 0;
            end if;
        end if;
end process slowClockProcess;
end Behavioral;