library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity decodificador is
    Port ( D : in STD_LOGIC_VECTOR (2 downto 0);       --entrada contador
            Y : out STD_LOGIC_VECTOR (7 downto 0));    --activador displays
end decodificador; 

architecture Behavioral of decodificador is
begin

process(D)
begin
    case D is
        when "000" => Y <= "11111110";
        when "001" => Y <= "11111101";
        when "010" => Y <= "11111011";
        when "011" => Y <= "11110111";
        when "100" => Y <= "11101111";
        when "101" => Y <= "11011111";
        when "110" => Y <= "10111111";
        when "111" => Y <= "01111111";
        when others => Y <= "11111111";
    end case;
end process;


end Behavioral;
