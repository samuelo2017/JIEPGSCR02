library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity principal is
    Port ( fastClock : in STD_LOGIC;
            bin : in STD_LOGIC_VECTOR (12 downto 0); --entrada numero bcd
            a,b,c,d,e,f,g,p : out STD_LOGIC;    --salida display
            Y : out STD_LOGIC_VECTOR (7 downto 0));     --seleccionador display
end principal;

architecture Behavioral of principal is
--conexiones 
signal slow_clk : STD_LOGIC;
signal count    : STD_LOGIC_VECTOR(2 downto 0);
signal bcd_data : STD_LOGIC_VECTOR(3 downto 0);
signal unidades : STD_LOGIC_VECTOR(3 downto 0);
signal decenas : STD_LOGIC_VECTOR(3 downto 0);
signal centenas : STD_LOGIC_VECTOR(3 downto 0);
signal miles : STD_LOGIC_VECTOR(3 downto 0);


begin
 
rel_inst : entity work.reloj
port map (
    fastClock => fastClock,
    slowClock => slow_clk,
    prescaler => 125000
);

cont_inst : entity work.contador
port map (
    Clk => slow_clk,
    Q => count
);

dec_inst : entity work.decodificador
port map (
    D => count
);

bcd_inst : entity work.binabcd
port map (
  bin => bin,
  unidades => unidades,
  decenas => decenas,
  centenas => centenas,
  miles => miles
);

multi_inst : entity work.mux
port map (
    num0 => unidades,
    num1 => decenas,
    num2 => centenas,
    num3 => miles,
    S => count,
    Y => bcd_data
);

conv_inst : entity work.convertidor
port map (
    X => bcd_data
);



end Behavioral;

