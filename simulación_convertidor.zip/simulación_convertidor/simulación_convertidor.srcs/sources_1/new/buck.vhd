library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.fixed_pkg.ALL;
use IEEE.fixed_float_types.ALL;

entity buck is
    Port (
        clk  : in  std_logic;
        rst  : in  std_logic;
        tick : in  std_logic;
        pwm  : in  std_logic;

        vC_o : out sfixed(7 downto -24);
        iL_o : out sfixed(7 downto -24)
    );
end buck;

architecture Behavioral of buck is

    signal Vin : sfixed(7 downto -24);

    constant R  : sfixed(7 downto -24) := to_sfixed(50.0,      7,  -24); -- 12Ω
    constant L  : sfixed(0 downto -31) := to_sfixed(0.001,     0,  -31); -- 1mH
    constant C  : sfixed(0 downto -31) := to_sfixed(0.001,    0,  -31); -- 1mF
    constant dt : sfixed(0 downto -31) := to_sfixed(0.0000002, 0,  -31); -- 200ns (0.2µs)
    constant Vin_int : integer := 48;                                      -- 24V

begin

    Vin <= to_sfixed(Vin_int, 7, -24);

    process(clk)
        variable iL :   sfixed (11 downto -86) := (others => '0');
        variable vC :   sfixed (19 downto -110) := (others => '0');
        variable T1_i : sfixed (8 downto -24) := (others => '0');
        variable T2_i : sfixed (9 downto -55) := (others => '0');
        variable sig_i: sfixed (10 downto -86) := (others => '0');
        variable T1_v : sfixed (15 downto -48) := (others => '0'); 
        variable T2_v : sfixed (16 downto -48) := (others => '0');
        variable T3_v : sfixed (17 downto -79) := (others => '0');
        variable sig_v: sfixed (18 downto -110) := (others => '0');
    begin
        if rising_edge(clk) then

            if rst = '1' then
                iL := to_sfixed(1, 11,  -86);   -- valor de prueba de 1 para verificar que no se afecta con el valor siguiente
                vC := to_sfixed(1, 19,  -110);

            elsif tick = '1' then

                -- Inductor
                if pwm = '1' then
                    T1_i := resize(Vin - vC, 8, -24);
                    T2_i := T1_i * dt;
                    sig_i := T2_i / L;    -- sig da un valor tan bajo que no afecta al sig
                else
                    T2_i := resize(-vC * dt, 9, -55);
                    sig_i := T2_i / L;
                end if;

                iL := resize(iL + sig_i, 11, -86);    --aumente el rango de il con la esperanza de que afectara el estado siguuiente

                -- Capacitor
                    T1_v := resize(vC / R, 15, -48);
                    T2_v := resize(iL - T1_v, 16, -48);
                    T3_v := T2_v * dt ;
                    sig_v := T3_v / C;

                vC := resize(vC + sig_v, 19, -110);
                    
            end if;
            
    vC_o <= resize(vC,7,-24, fixed_saturate, fixed_round);
    iL_o <= resize(iL,7,-24, fixed_saturate, fixed_round);
        end if;
    end process;

end Behavioral;