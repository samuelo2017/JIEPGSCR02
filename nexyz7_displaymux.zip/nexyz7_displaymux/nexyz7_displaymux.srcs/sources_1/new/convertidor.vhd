library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity convertidor is
Port (
    X : in STD_LOGIC_VECTOR (3 downto 0);    --entrada bcd
    a,b,c,d,e,f,g,p : out std_logic          --salida 7 segmentos
);
end convertidor;

architecture Behavioral of convertidor is
begin

process(X)
begin
    case X is
        when "0000" => -- 0
            a<='1'; b<='1'; c<='1'; d<='1'; e<='1'; f<='1'; g<='0'; p<='0';
        
        when "0001" => -- 1
            a<='0'; b<='1'; c<='1'; d<='0'; e<='0'; f<='0'; g<='0'; p<='0';
        
        when "0010" => -- 2
            a<='1'; b<='1'; c<='0'; d<='1'; e<='1'; f<='0'; g<='1'; p<='0';
        
        when "0011" => -- 3
            a<='1'; b<='1'; c<='1'; d<='1'; e<='0'; f<='0'; g<='1'; p<='0';
        
        when "0100" => -- 4
            a<='0'; b<='1'; c<='1'; d<='0'; e<='0'; f<='1'; g<='1'; p<='0';
        
        when "0101" => -- 5
            a<='1'; b<='0'; c<='1'; d<='1'; e<='0'; f<='1'; g<='1'; p<='0';
        
        when "0110" => -- 6
            a<='1'; b<='0'; c<='1'; d<='1'; e<='1'; f<='1'; g<='1'; p<='0';
        
        when "0111" => -- 7
            a<='1'; b<='1'; c<='1'; d<='0'; e<='0'; f<='0'; g<='0'; p<='0';
        
        when "1000" => -- 8
            a<='1'; b<='1'; c<='1'; d<='1'; e<='1'; f<='1'; g<='1'; p<='0';
        
        when "1001" => -- 9
            a<='1'; b<='1'; c<='1'; d<='1'; e<='0'; f<='1'; g<='1'; p<='0';
        
        when "1111" => --punto
        a<='0'; b<='0'; c<='0'; d<='0'; e<='0'; f<='0'; g<='0'; p<='1';
        
        when others =>
            a<='0'; b<='0'; c<='0'; d<='0'; e<='0'; f<='0'; g<='0'; p<='0'; 
    end case;
end process;

end Behavioral;
