library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.fixed_pkg.ALL;

entity decimal is
    Port (
        decimal : in UNSIGNED(11 downto 0);    
        decimas : out UNSIGNED(3 downto 0);
        centesimas : out UNSIGNED(3 downto 0);
        milesimas : out UNSIGNED(3 downto 0);
        diezmilesimas : out UNSIGNED (3 downto 0)
    );
end decimal;

architecture Behavioral of decimal is

    signal valor_fijo : ufixed(0 downto -11);

begin

end Behavioral;