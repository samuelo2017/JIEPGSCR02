library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity reloj is
    Port (
        clk  : in  std_logic;
        tick : out std_logic
    );
end reloj;

architecture Behavioral of reloj is
    signal counter : integer := 0;
begin

    process(clk)
    begin
        if rising_edge(clk) then
            if counter = 19 then
                counter <= 0;
                tick <= '1';                     --salida de 5MHz
            else
                counter <= counter + 1;
                tick <= '0';
            end if;
        end if;
    end process;

end Behavioral;