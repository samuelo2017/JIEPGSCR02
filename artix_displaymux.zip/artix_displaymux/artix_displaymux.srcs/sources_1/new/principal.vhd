library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity principal is
    Port ( fastClock : in STD_LOGIC;
            num0,num1,num2,num3,num4,num5,num6,num7 : in STD_LOGIC_VECTOR (3 downto 0); --entrada numero bcd
            a,b,c,d,e,f,g,p : out STD_LOGIC;    --salida display
            Y : out STD_LOGIC_VECTOR (7 downto 0));     --seleccionador display
end principal;

architecture Behavioral of principal is
--conexiones 
signal slow_clk : STD_LOGIC;
signal count    : STD_LOGIC_VECTOR(2 downto 0);
signal bcd_data : STD_LOGIC_VECTOR(3 downto 0);

begin

rel_inst : entity work.reloj
port map (
    fastClock => fastClock,
    slowClock => slow_clk,
    prescaler => 62500
);

cont_inst : entity work.contador
port map (
    Clk => slow_clk,
    Q => count
);

dec_inst : entity work.decodificador
port map (
    D => count,
    Y => Y
);

multi_inst : entity work.mux
port map (
    num0 => num0,
    num1 => num1,
    num2 => num2,
    num3 => num3,
    num4 => num4,
    num5 => num5,
    num6 => num6,
    num7 => num7,
    S => count,
    Y => bcd_data
);

conv_inst : entity work.convertidor
port map (
    X => bcd_data,
    a => a,
    b => b,
    c => c,
    d => d,
    e => e,
    f => f,
    g => g,
    p => p
);



end Behavioral;
