library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity pwm is
    Port (
        clk   : in  std_logic;
        duty  : in  std_logic_vector(7 downto 0);
        pwm_out : out std_logic
    );
end pwm;

architecture Behavioral of pwm is
    signal counter  : unsigned(10 downto 0) := (others => '0');
    signal duty_int : unsigned(10 downto 0);
begin
 duty_int <= resize(unsigned(duty), 11);
    process(clk)
    begin
        if rising_edge(clk) then

            if counter = 1999 then
                counter <= (others => '0');
            else
                counter <= counter + 1;
            end if;

            if counter < duty_int then
                pwm_out <= '1';
            else
                pwm_out <= '0';
            end if;
        end if;
    end process;
end Behavioral;