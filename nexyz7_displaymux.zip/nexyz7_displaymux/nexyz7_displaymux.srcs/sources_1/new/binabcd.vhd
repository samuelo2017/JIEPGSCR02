library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity binabcd is
    Port (
        bin   : in STD_LOGIC_VECTOR(12 downto 0);    --entrada de binarios
        miles    : out STD_LOGIC_VECTOR(3 downto 0);
        centenas : out STD_LOGIC_VECTOR(3 downto 0);
        decenas  : out STD_LOGIC_VECTOR(3 downto 0);
        unidades : out STD_LOGIC_VECTOR(3 downto 0)
    );
end binabcd;

architecture Behavioral of binabcd is
begin
process(bin)
    variable temp : unsigned(28 downto 0); -- espacio para BCD + binario
begin
    temp := (others => '0');
    temp(12 downto 0) := unsigned(bin);

    for i in 0 to 12 loop
        
        -- Ajuste BCD
        if temp(16 downto 13) > 4 then
            temp(16 downto 13) := temp(16 downto 13) + 3;
        end if;
        if temp(20 downto 17) > 4 then
            temp(20 downto 17) := temp(20 downto 17) + 3;
        end if;
        if temp(24 downto 21) > 4 then
            temp(24 downto 21) := temp(24 downto 21) + 3;
        end if;
        if temp(28 downto 25) > 4 then
            temp(28 downto 25) := temp(28 downto 25) + 3;
        end if;

        -- Shift
        temp := temp(27 downto 0) & '0';
    end loop;

    -- Salidas
    unidades <= std_logic_vector(temp(16 downto 13));
    decenas  <= std_logic_vector(temp(20 downto 17));
    centenas  <= std_logic_vector(temp(24 downto 21));
    miles    <= std_logic_vector(temp(28 downto 25));

end process;
end Behavioral;
