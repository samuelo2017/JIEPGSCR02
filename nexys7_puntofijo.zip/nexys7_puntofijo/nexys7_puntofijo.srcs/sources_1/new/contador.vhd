library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

--Declaración entidades
entity contador is
    Port ( Clk : in STD_LOGIC;
            Q : out UNSIGNED (2 downto 0) );
end contador;

--definición de arquitectura
architecture Behavioral of contador is

begin

procCounter:process(Clk) is
variable sQ: integer range 0 to 7 := 0;
begin
        if rising_edge(Clk) then
                if (sQ >= 7) then 
                        sQ := 0;
                else
                sQ := sQ + 1;
                end if;
        end if;
        Q <= to_unsigned(sQ, Q'length);
end process procCounter;

end Behavioral;
