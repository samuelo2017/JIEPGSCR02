library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity mux is
    Port ( num0 : in UNSIGNED (3 downto 0);      --inicio convertidos de bin a bcd
            num1 : in UNSIGNED (3 downto 0);
            num2 : in UNSIGNED (3 downto 0);
            num3 : in UNSIGNED (3 downto 0);
            num4 : in UNSIGNED (3 downto 0);      --inicio convertidos de bin a bcd
            num5 : in UNSIGNED (3 downto 0);
            num6 : in UNSIGNED (3 downto 0);
            num7 : in UNSIGNED (3 downto 0);     --finalización convertidos de bin a bcd
            S : in UNSIGNED (2 downto 0);       --gobernancia
            Y: out UNSIGNED (3 downto 0);      --numero seleccionado
            punto: out STD_LOGIC);
end mux;

architecture Behavioral of mux is
begin

WITH S SELECT
    Y <= num0 WHEN "000",
         num1 WHEN "001",
         num2 WHEN "010",
         num3 WHEN "011",
         num4 WHEN "100",
         num5 WHEN "101",
         num6 WHEN "110",
         num7 WHEN others;
    punto <= '0' WHEN S="100" ELSE '1';

end Behavioral;

