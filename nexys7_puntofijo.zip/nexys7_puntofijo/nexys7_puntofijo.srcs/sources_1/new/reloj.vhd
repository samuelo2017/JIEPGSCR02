library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
--Declaración de entidad
entity reloj is
    generic (prescaler : INTEGER RANGE 0 TO 50000000);
    Port ( fastClock : in STD_LOGIC;              --entrada reloj
            slowClock : out STD_LOGIC);         --salida reloj
end reloj;

--Definición de la arquitectura
architecture Behavioral of reloj is
begin
slowClockProcess: process(fastClock)
        variable countFastCycles: INTEGER RANGE 0 TO 50000000 := 0;
        variable vSlowClock : STD_LOGIC := '0';
begin
        if  rising_edge(fastClock) then 
            countFastCycles := countFastCycles + 1;           
            if countFastCycles = prescaler then
                vSlowClock := NOT vSlowClock;
                countFastCycles := 0;
            end if;
        end if;
        slowClock <= vSlowClock;
end process slowClockProcess;
end Behavioral;