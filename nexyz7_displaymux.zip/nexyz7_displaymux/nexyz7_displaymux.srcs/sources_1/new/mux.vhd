library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mux is
    Port ( num0 : in STD_LOGIC_VECTOR (3 downto 0);      --inicio convertidos de bin a bcd
            num1 : in STD_LOGIC_VECTOR (3 downto 0);
            num2 : in STD_LOGIC_VECTOR (3 downto 0);
            num3 : in STD_LOGIC_VECTOR (3 downto 0);     --finalización convertidos de bin a bcd
            S : in STD_LOGIC_VECTOR (2 downto 0);       --gobernancia
            Y: out STD_LOGIC_VECTOR (3 downto 0));      --numero seleccionado
end mux;

architecture Behavioral of mux is
begin
process(num0,num1,num2,num3,S)
begin
    case S is
        when "000" => Y <= num0;
        when "001" => Y <= num1;
        when "010" => Y <= num2;
        when "011" => Y <= num3;
        when "100" => Y <= "1111";
        when "101" => Y <= "1111";
        when "110" => Y <= "1111";
        when "111" => Y <= "1111";
        when others => Y <= (others => '0');
    end case;
end process;

end Behavioral;

