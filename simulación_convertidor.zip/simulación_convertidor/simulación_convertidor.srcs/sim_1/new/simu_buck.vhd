library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.fixed_pkg.ALL;
  
entity simu_buck is
end simu_buck;

architecture sim of simu_buck is

    signal clk  : std_logic := '0';
    signal rst  : std_logic := '0';
    signal duty : std_logic_vector (7 downto 0);

    signal vC   : sfixed(7 downto -24);
    signal iL   : sfixed(7 downto -24);

begin

    uut: entity work.principal
        port map (
            clk  => clk,
            rst  => rst,
            duty => duty,
            vC   => vC,
            iL   => iL
        );

    -- Clock 100 MHz
    clk_process: process
    begin
        while true loop
            clk <= '0';
            wait for 5 ns;
            clk <= '1';
            wait for 5 ns;
        end loop;
    end process;

stim: process
begin
    rst <= '1';        -- activar reset
    wait for 50 ns;
    rst <= '0';        -- liberar reset

    duty <= std_logic_vector(to_unsigned(106, 8)); -- 41.6%

    wait;
end process;


end sim;