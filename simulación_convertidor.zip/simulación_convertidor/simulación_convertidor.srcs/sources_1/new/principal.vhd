library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use IEEE.fixed_pkg.ALL;

entity principal is
    Port (
        clk     : in  std_logic; 
        rst     : in  std_logic;                          --reseteo de sistema

        duty    : in std_logic_vector(7 downto 0); 
        vC      : out sfixed(7 downto -24);
        iL      : out sfixed(7 downto -24)   

    );
end principal;

architecture Behavioral of principal is

    signal pwm      : std_logic;

    signal tick     : std_logic;
    signal vout_int : unsigned(15 downto 0);

begin

    -- PWM
    pwm_inst : entity work.pwm
        port map (
            clk   => clk,
            duty  => duty,
            pwm_out => pwm
        );

    -- reloj para que quede a 1MHz
    clk_en_inst : entity work.reloj
        port map (
            clk  => clk,
            tick => tick     --salida reducida de reloj
        );

    -- Modelo Buck
    buck_inst : entity work.buck
        port map (
            clk   => clk,
            rst   => rst,
            tick  => tick,
            pwm   => pwm,
            vC_o  => vC,
            iL_o  => iL
        );

end Behavioral;