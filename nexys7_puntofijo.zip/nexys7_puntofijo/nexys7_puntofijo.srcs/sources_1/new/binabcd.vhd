library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity binabcd is
    Port (
        bin   : in UNSIGNED(3 downto 0);    
        decenas  : out UNSIGNED(3 downto 0);
        unidades : out UNSIGNED(3 downto 0)
    );
end binabcd;

architecture Behavioral of binabcd is
begin
process(bin)
    variable temp : unsigned(11 downto 0); 
begin
    temp := (others => '0');
    temp(3 downto 0) := bin;

    for i in 1 to bin'length loop
        
        if temp(7 downto 4) > 4 then
            temp(7 downto 4) := temp(7 downto 4) + 3;
            else
        end if;
        if temp(11 downto 8) > 4 then
            temp(11 downto 8) := temp(11 downto 8) + 3;
        end if;

        temp := shift_left (temp, 1);
--        temp := temp(27 downto 0) & '0';
    end loop;

    unidades <= temp(7 downto 4);
    decenas  <= temp(11 downto 8);

end process;
end Behavioral;
