library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

--Declaración entidades
entity contador is
    Port ( Clk : in STD_LOGIC;
            Q : inout STD_LOGIC_VECTOR (2 downto 0) );
end contador;

--definición de arquitectura
architecture Behavioral of contador is
signal sQ: UNSIGNED (2 downto 0) := (others => '0'); -- :="000"
begin

process(Clk)
begin
        if rising_edge(Clk) then
                if (sQ = 7) then 
                        sQ <= (others => '0');
                else
                sQ <= sQ + 1;
                end if;
        end if;
end process;
Q <= STD_LOGIC_VECTOR (sQ);

end Behavioral;
