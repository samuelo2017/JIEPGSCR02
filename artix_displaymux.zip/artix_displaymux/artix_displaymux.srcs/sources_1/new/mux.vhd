library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mux is
    Port ( num0 : in STD_LOGIC_VECTOR (3 downto 0);
            num1 : in STD_LOGIC_VECTOR (3 downto 0);
            num2 : in STD_LOGIC_VECTOR (3 downto 0);
            num3 : in STD_LOGIC_VECTOR (3 downto 0);
            num4 : in STD_LOGIC_VECTOR (3 downto 0);
            num5 : in STD_LOGIC_VECTOR (3 downto 0);
            num6 : in STD_LOGIC_VECTOR (3 downto 0);
            num7 : in STD_LOGIC_VECTOR (3 downto 0);
            S : in STD_LOGIC_VECTOR (2 downto 0);       --gobernancia
            Y: out STD_LOGIC_VECTOR (3 downto 0));      --numero seleccionado
end mux;

architecture Behavioral of mux is
begin
process(num0,num1,num2,num3,num4,num5,num6,num7,S)
begin
    case S is
        when "000" => Y <= num0;
        when "001" => Y <= num1;
        when "010" => Y <= num2;
        when "011" => Y <= num3;
        when "100" => Y <= num4;
        when "101" => Y <= num5;
        when "110" => Y <= num6;
        when "111" => Y <= num7;
        when others => Y <= (others => '0');
    end case;
end process;

end Behavioral;
