library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity principal is
    Port ( fastClock : in STD_LOGIC;
            entero : in UNSIGNED (3 downto 0); --entrada parte entera
            decimal : in UNSIGNED (11 downto 0); -- entrada parte decimal
            Ka : out STD_LOGIC_VECTOR (6 downto 0);    --salida display
            punto : out STD_LOGIC;                     --punto
            Y : out STD_LOGIC_VECTOR (7 downto 0));     --seleccionador display
end principal;

architecture Behavioral of principal is
--conexiones 
signal slow_clk : STD_LOGIC;
signal count    : UNSIGNED(2 downto 0);
signal bcd_data : UNSIGNED(3 downto 0);
signal unidades : UNSIGNED(3 downto 0);
signal decenas : UNSIGNED(3 downto 0);
signal decimas : UNSIGNED(3 downto 0);
signal centesimas : UNSIGNED(3 downto 0);
signal milesimas : UNSIGNED(3 downto 0);
signal diezmilesimas : UNSIGNED(3 downto 0);

begin
 
rel_inst : entity work.reloj
generic map(prescaler => 125000)
port map (
    fastClock => fastClock,
    slowClock => slow_clk
);

cont_inst : entity work.contador
port map (
    Clk => slow_clk,
    Q => count
);

dec_inst : entity work.decodificador
port map (
    D => count,
    Y => Y
);

bcd_inst : entity work.binabcd
port map (
  bin => entero,
  unidades => unidades,
  decenas => decenas
);

decimal_inst : entity work.decimal
port map (
  decimal => decimal,
  decimas => decimas,
  centesimas => centesimas,
  milesimas => milesimas,
  diezmilesimas => diezmilesimas
);


multi_inst : entity work.mux
port map (
    num0 => diezmilesimas,  
    num1 => milesimas,    
    num2 => centesimas,  
    num3 => decimas,    
    num4 => unidades,
    num5 => decenas,
    num6 => "1110",
    num7 => "1110",
    S => count,
    Y => bcd_data,
    punto => punto
);

conv_inst : entity work.convertidor
port map (
    X => bcd_data,
    Ka => Ka
);



end Behavioral;

